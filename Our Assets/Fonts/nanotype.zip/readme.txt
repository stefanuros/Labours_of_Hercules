Free to use, edit, redistribute for personal or commercial purposes. 

Created by spacebake.
jake@black-cross.co.uk